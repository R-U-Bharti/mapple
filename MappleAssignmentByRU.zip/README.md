get distance
get place details